# ESP8266-Wifi-NeoPixel
Arduino code to control a strip of neopixels via wifi with the ESP8266

Initial release and tested. Be sure you have the NeoPixel Library and ESP8266 Board installed in Arduino 1.6.x.
NeoPixels controlled by GPIO 2
Code is still work in progress. I need to integrate a software interrupt to chage the neopixels and display webpage before the "cycle" completes.
